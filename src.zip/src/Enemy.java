import java.util.ArrayList;

public class Enemy extends LivingBeing {
	private boolean stunned;
	private int stunDuration;

	public boolean getStunned(){return stunned;};
	public int getStunDuration(){return stunDuration;};

	public void setStunned(boolean stunned){this.stunned = stunned;};
	public void setStunDuration(int stunDuration){this.stunDuration = stunDuration;};

	public Enemy(){
		stunned = false;
		stunDuration = 7;
		super();
	}
	@Override
	public String sign(){
		return "\033[35mMX\033[0m";
	}
	public void moveTowardsTarget(Floor floor, Position position){
		ArrayList<Position> path = floor.aStar(getPos(), position);
		if(path.size() > 1)
			setPos(path.get(1));
	}
	public void dealDamage(Player player){
		stunned = true;
		player.setHitPoint(player.getHitPoint() - 1);
	}
}

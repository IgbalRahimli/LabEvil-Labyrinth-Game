public class Wall extends Tile {
	public Wall(){
		super();
		setPassable(false);
	}
	@Override
	public String sign(){
		return "##";
	}
}

public class Tile {
	private boolean passable;
	private boolean safe;
	public Tile(){
		safe = false;
		passable = true;
	}
	public String sign(){
		return "  ";
	}
	public boolean interaction(Player player){return false;}
	public boolean getPassable(){return passable;}
	public void setPassable(boolean passable){this.passable = passable;}

	public boolean getSafe(){return safe;}
	public void setSafe(boolean safe){this.safe = safe;}
}

public class Ladder extends Tile {
	private int upOrDown;
	private World world;
	public Ladder(int upOrDown, World world){
		super();
		setPassable(false);
		this.upOrDown = upOrDown;
		this.world = world;
	}
	@Override
	public String sign(){
		return "\033[1;35m==\033[0m";
	}

	@Override
	public boolean interaction(Player player){
		world.getPlayer().getPos().setRow(15 - world.getPlayer().getPos().getRow());
		world.setCurrentFloor(world.getCurrentFloor() + upOrDown);
		world.getEnemy().setPos(world.getFloors()[world.getCurrentFloor()].getEnemySpot());
		return true;
	}
}

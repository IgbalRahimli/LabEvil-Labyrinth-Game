public class Door extends Wall {
	private int requiredKeyCount;
	private Item requiredKey;
	@Override
	public String sign(){
		if(getPassable()){
			if(requiredKey.getType() == 2)
				return "\033[33m}{\033[0m";

			if(requiredKeyCount == 0)
				return "\033[32m][\033[0m";
			return "\033[31m][\033[0m";
		}
		if(requiredKey.getType() == 2)
			return "\033[33m{}\033[0m";
		if(requiredKeyCount == 0)
			return "\033[32m[]\033[0m";
		return "\033[31m[]\033[0m";

	}
	@Override
	public boolean interaction(Player player){
		if(requiredKeyCount == 0){
			setPassable(getPassable() ^ true);
			return true;
		}

		if(player.useItem(requiredKey.getType()) != null){
			requiredKeyCount = (requiredKeyCount > 1) ? (requiredKeyCount - 1): 0;
			World.Dialog.setDialog("You used the key");
		} else {
			World.Dialog.setDialog("You ain't got the key");
		}
		return false;
	}
	public Door(Item requiredKey, int requiredKeyCount){
		super();
		this.requiredKeyCount = requiredKeyCount;
		this.requiredKey = requiredKey;
	}
}


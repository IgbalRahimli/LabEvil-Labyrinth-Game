public class LivingBeing {
	private Position position;
	public String sign(){
		return "LB";
	}
	public LivingBeing(){
		position = new Position();
	}
	public Position getLookedPos(Direction direction){
		Position pos = new Position(getPos().getRow(), getPos().getColumn());
		switch(direction){
			case Direction.LEFT:
				pos.setColumn(pos.getColumn() - 1);
				break;
			case Direction.UP:
				pos.setRow(pos.getRow() - 1);
				break;
			case Direction.RIGHT:
				pos.setColumn(pos.getColumn() + 1);
				break;
			case Direction.DOWN:
				pos.setRow(pos.getRow() + 1);
				break;
		}
		return pos;
	}
	public boolean move(Floor floor, Direction direction){
		Position pos = getLookedPos(direction);
		if(floor.getTileAt(pos) != null){
			if(floor.getTileAt(pos).getPassable()){
				setPos(pos);
				return true;
			}
		}
		return false;
	}
	public void setPos(Position position){
		this.position = position;
	}
	public Position getPos(){return position;}
}

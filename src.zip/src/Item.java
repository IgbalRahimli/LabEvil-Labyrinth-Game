public class Item {
	private int type;
	private String sign;
	private String name;
	public Item(int type, String name, String sign){
		this.type = type;
		this.sign = sign;
		this.name = name;
	}
	public String getSign(){return sign;}
	public String getName(){return name;}
	public int getType(){return type;}
}

import java.util.Scanner;

public class LabyrinthMansion {
	public static void printScreen(Floor floor, Player player){
		System.out.print("\u001b[2J\u001b[H");
		floor.printFloor();

		System.out.print("Health: ");
		for(int i = 0; i < player.getHitPoint(); i++){
			System.out.print("\033[1;31m[+]\033[0m ");
		}
		String[] strings = {"Strength", "Simple Keys", "Definitely Not Simple Key"};
		System.out.println();
		for(int type = 0; type < 3; type++){
			System.out.print(strings[type] + ": ");
			for(int i = 0; i < player.getItemCount(); i++)
				if(player.getItems()[i].getType() == type)
    				System.out.print(player.getItems()[i].getSign() + " ");
			System.out.println();
		}

		System.out.println("+----------------------------------+");
		System.out.printf("  %-32s  \n", World.Dialog.getDialog());
		System.out.println("+----------------------------------+");
	}
	public static boolean gameRun(){
		String[][] map = {
			{
			"##=^############################",
			"##      ##            ##      ##",
			"######  ##  ########  ##  ##  ##",
			"##      ##  ##            ##  ##",
			"##  ######  ##  ############  ##",
			"##          ##        ##!!    ##",
			"##  ################  ##########",
			"##                ##  ##      ##",
			"##  ############  ##  ##  ##  ##",
			"##  ##        ##          ##  ##",
			"##  ##  ####  ####  ########  ##",
			"##  ##  ##      ##  ##        ##",
			"##      ##  ##  ##  ##  ########",
			"##########  ##  ##  ##  ##____##",
			"##CS        ##      ##  []__CN##",
			"################################"
			},
			{
			"############################=^##",
			"####      ##      ##      ##  ##",
			"####  ##  C2  ##      ##      ##",
			"####  ######################  ##",
			"##          ##      ####      ##",
			"##  ######  ##  ##        ##  ##",
			"##  ##      ##[]############  ##",
			"##  ##  ##  ##____##      ##  ##",
			"##  ##  ##  ##__CN##  ##      ##",
			"##      ##  ########  ####  ####",
			"##########              ##  ####",
			"##      ##  ##########  ##  ####",
			"##  ##  ##              ##  ####",
			"##  ##  ##  ##############  ####",
			"##  ##      ##!!            ####",
			"##=v############################" 
			},
			{
			"##=^############################",
			"##  ##                ##      ##",
			"##  ##  ############  ##  ##C1##",
			"##      ##        ##  ##  ######",
			"######  ##  ####  ##          ##",
			"##      ##  ##    ##  ######  ##",
			"##  ######  ##  ####      ##  ##",
			"{}LK    ##  ##  ##    ##  ##!!##",
			"######  ##  ##  ##  ####  ######",
			"##      ##  ##      ##        ##",
			"##  ######  ######  ##  ####  ##",
			"##  ##          ##  ##  ##    ##",
			"##      ######  ##  ##  ##  ####",
			"##########      ##  ##  ##  ####",
			"##__        ######      ##    ##",
			"############################=v##" 
			},
			{
			"############################=^##",
			"##############CS          ##  ##",
			"##!!        ##  ########  ##  ##",
			"##  ######  ##      ##    ##  ##",
			"##      ##  ######  ##  ####  ##",
			"##  ##  ##      ##  ##        ##",
			"##    C3##  ##      ########  ##",
			"##########  ##  ##    ##      ##",
			"##          ##  ####  ##  ##  ##",
			"##  ##########    ##      ##  ##",
			"##          ####  ##########  ##",
			"##  ##  ##    ##              ##",
			"##  ##  ####      ##  ##########",
			"##  ##    ##########      ##__##",
			"##  ####              ##      ##",
			"##=v############################"
			},
			{
			"################################",
			"##CN__[]          ##    CS    ##",
			"##____##########  ##  ######  ##",
			"########          ##      ##  ##",
			"####      ##############  ##  ##",
			"####  ##  ##          ##  ##  ##",
			"####  ##  ##  ##  ##  ##      ##",
			"##    ##  ##  ##  ##  ######!!##",
			"##  ####  ##  ##  ##      ##  ##",
			"##        ##  ##  ##  ##  ##  ##",
			"####  ######  ##  ##  ##  ##  ##",
			"####  ##      ##  ##  ##  ##  ##",
			"##    ##  ######  ##  ##      ##",
			"##  ####  ##          ##########",
			"##            ######          ##",
			"############################=v##"
			}
		};
		Floor floor;
		World world = new World(map, 2);


		Scanner myObj = new Scanner(System.in);
    	String input;
		Direction direction = Direction.RIGHT;
		boolean move, run;

		Player player = world.getPlayer();
		Enemy enemy = world.getEnemy();

		player.setPos(world.getFloors()[world.getCurrentFloor()].getPlayerSpot());
		enemy.setPos(world.getFloors()[world.getCurrentFloor()].getEnemySpot());

		run = true;
		do {
			floor = world.getFloors()[world.getCurrentFloor()];
			printScreen(floor, player);

    		System.out.print("Move: ");
    		input = myObj.nextLine();
			move = true;


			if (enemy.getStunned()) {
				enemy.setStunDuration(enemy.getStunDuration() - 1);
				if (enemy.getStunDuration() == 0) {
					enemy.setStunned(false);
					enemy.setStunDuration(5);
				}
			} else {
				if(floor.getTileAt(player.getPos()).getSafe())
					enemy.moveTowardsTarget(floor, floor.getEnemySpot());
				else
					enemy.moveTowardsTarget(floor, player.getPos());
			}

			switch(input.trim()){
				case "d":
					direction = Direction.RIGHT;
					break;
				case "w":
					direction = Direction.UP;
					break;
				case "a":
					direction = Direction.LEFT;
					break;
				case "s":
					direction = Direction.DOWN;
					break;
				case "e":
					move = false;
					player.interact(floor, direction);
					break;
				case "q":
					return false;
			}
			if(move){
				player.move(floor, direction);
				if(floor.getTileAt(player.getLookedPos(direction)) != null)
				World.Dialog.setDialog("Looking at " + floor.getTileAt(player.getLookedPos(direction)).sign());

				if(floor.getTileAt(player.getPos()).sign().equals("\033[33m}{\033[0m")){
					run = false;
					World.Dialog.setDialog("[ YOU WIN ]");
					printScreen(floor, player);
				}
			}

			if ((enemy.getPos().getRow() == player.getPos().getRow()) && 
				(enemy.getPos().getColumn() == player.getPos().getColumn()) &&
				!enemy.getStunned()) 
			{
				enemy.dealDamage(player);
				if(player.getHitPoint() == 0){
					run = false;
					World.Dialog.setDialog("[ YOU DIED ]");
					printScreen(floor, player);
				}
			}
		} while(run);

		System.out.print("Do you want to continue (Y/n): ");
    	input = myObj.nextLine();
		if(input.trim().toLowerCase().equals("n"))
			return false;
		return true;
	}

	public static void main(String[] args){
		while(gameRun());
	}
}

public class Crate extends Tile {
	private Item containedItem;
	private int requiredStenght;
	public Crate(Item containedItem, int requiredStenght){
		super();
		setPassable(false);
		this.containedItem = containedItem;
		this.requiredStenght = requiredStenght;
	}
	@Override
	public String sign(){
		String result;

		if(getPassable()){
			result = "..";
		}
		else if(containedItem.getType() == 0){
			result = "\033[1;32mC" + containedItem.getName().substring(0, 1);
		}
		else if(containedItem.getType() == 1){
			result = "\033[31mC" + requiredStenght;
		}
		else
			result = "\033[33mC" + containedItem.getName().substring(0, 1);
		return result + "\033[0m";
	}
	@Override
	public boolean interaction(Player player){
		if(getPassable()){
			return false;
		}

		int spinach = player.countItem(0);

		if(requiredStenght <= spinach){
			if(!player.takeItem(containedItem))
				return false;
			setPassable(true);
			return true;
		}
		else {
			World.Dialog.setDialog("Thou art weak");
		}
		return false;
	}
}

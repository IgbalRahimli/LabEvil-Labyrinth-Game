import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;

public class Floor {
	private Player player;
	private Enemy enemy;
	private World world;
	private Tile[][] tiles;
	private Position playerSpot;
	private Position enemySpot;

	public Position getPlayerSpot(){return playerSpot;}
	public Position getEnemySpot(){return enemySpot;}

	public void printFloor(){
		Position ppos = player.getPos();
		Position epos = enemy.getPos();

		for(int i = 0; i < tiles.length; i++){
			for(int j = 0; j < tiles[0].length; j++){
				if((i == ppos.getRow()) && j == ppos.getColumn())
					System.out.print(player.sign());
				else if((i == epos.getRow()) && j == epos.getColumn())
					System.out.print(enemy.sign());
				else if(tiles[i][j].getSafe())
					System.out.print("\033[1;36m__\033[0m");
				else
					System.out.print(tiles[i][j].sign());
			}
			System.out.println();
		}
	}

	public void loadFloor(String[] floor){
		this.tiles = new Tile[floor.length][floor[0].length() / 2];
		for(int i = 0; i < floor.length; i++){
			for(int j = 0; j < floor[0].length() / 2; j++){
				switch(floor[i].substring(2 * j, 2 * (j + 1))){
					case "##":
						tiles[i][j] = new Wall();
						break;
					case "[]":
						tiles[i][j] = new Door(new Item(1, "Simple Key", "o-+"), 1);
						break;
					case "{}":
						tiles[i][j] = new Door(new Item(2, "Non-simple Key", "o-="), 3);
						break;
					case "C1":
						tiles[i][j] = new Crate(new Item(1, "Simple Key","\033[1;31mo-+\033[0m"), 1);
						break;
					case "C2":
						tiles[i][j] = new Crate(new Item(1, "Simple Key","\033[1;31mo-+\033[0m"), 2);
						break;
					case "C3":
						tiles[i][j] = new Crate(new Item(1, "Simple Key","\033[1;31mo-+\033[0m"), 3);
						break;
					case "CS":
						tiles[i][j] = new Crate(new Item(0, "Spinach","\033[1;32m[^]\033[0m"), 0);
						break;
					case "CN":
						tiles[i][j] = new Crate(new Item(2, "Non-simple Key","\033[33mo-=\033[0m"), 0);
						break;
					case "=^":
						tiles[i][j] = new Ladder(+1, world);
						break;
					case "=v":
						tiles[i][j] = new Ladder(-1, world);
						break;
					case "LK":
						playerSpot = new Position(i, j);
						tiles[i][j] = new Tile();
						break;
					case "__":
						tiles[i][j] = new Tile();
						tiles[i][j].setSafe(true);
						break;
					case "!!":
						enemySpot = new Position(i, j);
					default:
						tiles[i][j] = new Tile();
						break;
				}
			}
		}
	}

	public Floor(World world, String[] floor, Player player, Enemy enemy){
		this.player = player;
		this.enemy = enemy;
		this.world = world;
		loadFloor(floor);
	}

	private int heuristic(Position a, Position b){
		return Math.abs(a.getRow() - b.getRow()) + Math.abs(a.getColumn() - b.getColumn());
	}

	private String key(Position p){
		return p.getRow() + "," + p.getColumn();
	}

	private Position[] getNeighbors(Position p){
		return new Position[]{
			new Position(p.getRow() - 1, p.getColumn()),
			new Position(p.getRow() + 1, p.getColumn()),
			new Position(p.getRow(), p.getColumn() - 1),
			new Position(p.getRow(), p.getColumn() + 1)
		};
	}

	public ArrayList<Position> aStar(Position start, Position goal){
		PriorityQueue<Node> open = new PriorityQueue<>(
			(a, b) -> Integer.compare(a.fCost, b.fCost)
		);

		HashMap<String, Position> cameFrom = new HashMap<>();
		HashMap<String, Integer> gCost = new HashMap<>();

		gCost.put(key(start), 0);
		open.add(new Node(start, 0, heuristic(start, goal)));

		while(!open.isEmpty()){
			Node currentNode = open.poll();
			Position current = currentNode.position;

			if(current.getRow() == goal.getRow() && current.getColumn() == goal.getColumn()){
				return reconstructPath(cameFrom, current);
			}

			for(Position neighbor : getNeighbors(current)){
				Tile tile = getTileAt(neighbor);

				if(tile == null){
					continue;
				}

				boolean isGoal = neighbor.getRow() == goal.getRow()
							&& neighbor.getColumn() == goal.getColumn();

				if(!tile.getPassable() && !isGoal){
					continue;
				}

				int newGCost = gCost.get(key(current)) + 1;
				String neighborKey = key(neighbor);

				if(!gCost.containsKey(neighborKey) || newGCost < gCost.get(neighborKey)){
					cameFrom.put(neighborKey, current);
					gCost.put(neighborKey, newGCost);

					int fCost = newGCost + heuristic(neighbor, goal);
					open.add(new Node(neighbor, newGCost, fCost));
				}
			}
		}

		return new ArrayList<>();
	}

	private ArrayList<Position> reconstructPath(HashMap<String, Position> cameFrom, Position current){
		ArrayList<Position> path = new ArrayList<>();

		path.add(current);

		while(cameFrom.containsKey(key(current))){
			current = cameFrom.get(key(current));
			path.add(0, current);
		}

		return path;
	}

	private static class Node {
		Position position;
		int gCost;
		int fCost;

		Node(Position position, int gCost, int fCost){
			this.position = position;
			this.gCost = gCost;
			this.fCost = fCost;
		}
	}

	public Tile getTileAt(Position position){
		if((0 <= position.getRow()) && (position.getRow() < tiles.length) && 
			(0 <= position.getColumn()) &&
			(position.getColumn() < tiles[0].length) ){
			return tiles[position.getRow()][position.getColumn()];
		}
		return null;
	}
}

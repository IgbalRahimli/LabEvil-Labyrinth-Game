public class Player extends LivingBeing {
	private int hitPoint, itemCount;
	private Item[] items;
	public Player(){
		items = new Item[9];
		itemCount = 0;
		hitPoint = 3;
		super();
	}

	@Override
	public String sign(){
		return "\033[34mLK\033[0m";
	}
	public Item[] getItems(){return items;}
	public void setHitPoint(int hitPoint){this.hitPoint = hitPoint;}
	public int getHitPoint(){return hitPoint;}
	public int getItemCount(){return itemCount;}
	public void setItemCount(int itemCount){this.itemCount = itemCount;}

	public boolean interact(Floor floor, Direction direction){
		Position pos = getLookedPos(direction);
		if(floor.getTileAt(pos) != null){
			floor.getTileAt(pos).interaction(this);
			return true;
		}
		return false;
	}

	public boolean takeItem(Item item){
		if(items.length <= itemCount){
			World.Dialog.setDialog("Inverntory is full");
			return false;
		}

		items[itemCount] = item;
		itemCount++;
		return true;
	}

	public Item useItem(int type){
		if(itemCount == 0)
			return null;

		int i;
		for(i = 0; (i < itemCount) && (items[i].getType() != type); i++);
		if(i == itemCount)
			return null;

		Item temp;
		temp = items[i];
		
		for(int j = i; j < itemCount - 1; j++){
			items[j] = items[j + 1];
		}
		itemCount--;

		return temp;
	}

	public int countItem(int type){
		int count = 0;
		for(int i = 0;  i < itemCount; i++)
			if(items[i].getType() == type)
				count++;
		return count;
	}
}

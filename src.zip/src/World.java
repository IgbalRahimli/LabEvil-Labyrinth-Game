public class World {
	public static class Dialog {
		private static String dialog = "";
		public static String getDialog(){return dialog;}
		public static void setDialog(String string){dialog = string;}
	}

	private Floor[] floors;
	private int currentFloor;
	private Player player;
	private Enemy enemy;

	public World(String[][] floors, int initialFloor){
		this.currentFloor = initialFloor;
		this.floors = new Floor[floors.length];
		this.player = new Player();
		this.enemy = new Enemy();

		for(int i = 0; i < floors.length; i++){
			this.floors[i] = new Floor(this, floors[i], player, enemy);
		}
	}
	public Floor[] getFloors(){return floors;}
	public int getCurrentFloor(){return currentFloor;}

	public Player getPlayer(){return player;}
	public Enemy getEnemy(){return enemy;}

	public void setCurrentFloor(int currentFloor){this.currentFloor = currentFloor;}
}
